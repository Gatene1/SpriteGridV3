function windowZRearrange(elementToLookAt) {

}

function windowZRefresh() {

}


function closeWindow(whichWindow) {

}
function openWindow(whichWindow) {

}